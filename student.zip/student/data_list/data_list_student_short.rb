require_relative 'data_table'
require_relative 'data_list'

class DataListStudentShort < DataList
  attr_accessor :count, :offset

  def initialize(data, offset = 0)
    super(data)
    @offset = offset
    @observers = []
  end

  def add_observer(observer)
    @observers << observer
  end

  def remove_observer(observer)
    @observers.delete(observer)
  end

  def notify
    @observers.each do |observer|
      observer.set_table_params(get_names, @count)
      observer.set_table_data(get_objects_array)
    end
  end

  private def get_names
    ["№", "full_name", "git", "contact"]
  end

  private def get_objects_array
    data.map.with_index(1) do |object, index|
      [index + @offset, object.initials, object.github, object.contact]
    end
  end
end