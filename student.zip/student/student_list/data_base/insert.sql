INSERT INTO student (surname, name, patronymic, birthdate, phone, mail, telegram, git)
VALUES
    ('Тестов', 'Тест', 'Тестович', '1999-01-02', '+79123456789', 'test@ya.ru', '@test', 'https://github.com/test'),
    ('Иванов', 'Иван', 'Иванович', '2000-02-01', '+79219876543', 'ivanov@mail.ru', '@ivanov', 'https://github.com/ivanov'),
    ('Сидоров', 'Павел', 'Николаевич', '2001-01-01', '+79554321098', 'psidorov@yandex.ru', '@psidorov', 'https://github.com/psidorov'),
    ('Петрова', 'Мария', 'Сергеевна', '1999-10-03', '+79876543210', 'mariapet@gmail.com', '@mariapet', 'https://github.com/mariapet'),
    ('Смирнов', 'Александр', 'Олегович', '2005-05-01', '+79098765432', 'alex.smirnov@mail.ru', '@alexsmirnov', 'https://github.com/alexsmirnov'),
    ('Кузнецова', 'Екатерина', 'Андреевна', '2006-12-10', '+79112233445', 'ek.kuznetsova@gmail.com', '@kuznetsovaek', 'https://github.com/kuznetsovaek');
