class TreeNode
  attr_accessor :obj, :left, :right
  def initialize(obj)
    @obj = obj
    @left = nil
    @right = nil
  end
end